import React, { Component, createRef } from 'react';
import Header from './Header';
import CropSelection from './CropSelection';
import News from './News';
import { Container, Row, Col, Card } from 'react-bootstrap';
import Tableau from "tableau-react";
import SignIn from './Signin';
import SignUp from './Signup';
import styles from './App.css';

class App extends Component {
  state = {
    selectedCrop: '',
    dashboardID: 'https://public.tableau.com/views/Historicalanalysiscornprice/Sheet1?:language=en-US&:display_count=y&:origin=viz_share_link',
    newsArticles: [],
    market: '',
    isLoggedIn: false
  };

  handleCropSelection = (crop, dashboardID, newsArticles, market) => {
    this.setState({
      selectedCrop: crop,
      dashboardID: dashboardID,
      newsArticles: newsArticles,
      market: market
    });
  };

  handleSignIn = () => {
    this.setState({ isLoggedIn: true });
  };

  handleSignUp = () => {
    this.setState({ isLoggedIn: true });
  };

  constructor(props) {
    super(props);
    this.scrollableDivRef = createRef();
  }

  componentDidUpdate() {
    // Scroll to the bottom of the div whenever its content changes
    this.scrollableDivRef.current.scrollTop = this.scrollableDivRef.current.scrollHeight;
  }

  render() {
    const { isLoggedIn } = this.state;

    if (!isLoggedIn) {
      return <SignIn onSignIn={this.handleSignIn} />;
    }

    return (
      <div>
        <Header />
        <main style={{ marginTop: '58px' }}>
          <Container fluid>
            <CropSelection onSelectCrop={this.handleCropSelection} />
            <Row>
              <Col md={9}>
                <Tableau url={this.state.dashboardID} options={{ debug: false }} />
              </Col>
              <Col md={3}>
                {this.state.market && (
                  <Card style={{ marginBottom: '20px' }}>
                    <Card.Body>
                      <Card.Text>{this.state.market}</Card.Text>
                    </Card.Body>
                  </Card>
                )}
                <div className="scrollable-div" ref={this.scrollableDivRef}>
                  <News articles={this.state.newsArticles} market={this.state.market} />
                </div>
              </Col>
            </Row>
          </Container>
        </main>
      </div>
    );
  }
}

export default App;
